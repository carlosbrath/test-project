<div class="container">
  <div class="section">
    <div class="row">
    </div>
    <form class="col s4" id="login-form">
      <div class="row">
        <div class="input-field hoverable col s6">
          <i class="material-icons prefix">account_circle</i>
          <input name="username" id="username" type="text" class="validate" required>
          <label for="username">Username</label>
        </div>
      </div>
      <div class="row">
        <div class="input-field hoverable col s6">
          <i class="material-icons prefix">password</i>
          <input name="password" id="password" type="password" class="validate" required>
          <label for="password">password</label>
        </div>
      </div>
      <div class="input-field s4">
        <input type="submit" value="Login" class="btn cutomer-regisbtn regis-btn">
      </div>
    </form>
  </div>
  <br><br>
</div>